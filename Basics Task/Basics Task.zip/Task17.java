//17. Write a Java program to add two binary numbers.
//Input Data:
//Input first binary number: 10
//Input second binary number: 11
//Expected Output

//Sum of two binary numbers: 101

import java.util.Scanner;

public class Task17{
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        
        System.out.print("Input first binary number: ");
        String binary1 = s.nextLine();
        
        System.out.print("Input second binary number: ");
        String binary2 = s.nextLine();
        
    }
}
