//41. Write a Java program to print the ASCII value of a given character.
//Expected Output

//The ASCII value of Z is :90

import java.util.Scanner;
public class Task41{
    public static void main(String[] args){
        char cha = 'Z';
        int asc = cha;
        System.out.println("The ASCII value of " + cha + " is: " + asc);
    }
}
